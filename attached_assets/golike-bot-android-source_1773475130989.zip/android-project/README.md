# 🛍️ GoLike Bot v8 — Android APK

Bot tự động nhận job GoLike | Shopee + Lazada | Gemini AI Captcha

## ⬇️ Tải APK

**[Download APK mới nhất → Releases](../../releases/latest)**

---

## 🔧 Fix lỗi "Chế độ cài đặt bị hạn chế" Android 14

Android 14 mặc định chặn cài APK từ ngoài. Làm theo 1 trong 2 cách:

### Cách 1 — Qua Chrome (dễ nhất)
1. Mở **Chrome** → tải APK
2. Khi popup hiện → nhấn **"Cài đặt"**
3. Nếu bị chặn: Settings → **Ứng dụng** → tìm **Chrome** → **Cài đặt ứng dụng không rõ nguồn** → **Bật**

### Cách 2 — Qua Settings
```
Settings (Cài đặt)
  → Ứng dụng (Apps)  
  → Quyền đặc biệt (Special app access)
  → Cài đặt ứng dụng không rõ (Install unknown apps)
  → Chọn Chrome hoặc Files
  → BẬT "Cho phép từ nguồn này"
```

### Cách 3 — Developer Options (dùng ADB)
```
Settings → About phone → tap Build number 7 lần
→ Developer options → Install via USB → ON
```

---

## 📱 Yêu cầu
- Android 8.0+ (API 26+)  
- **Termux** đã cài Python:
```bash
pkg install python && pip install requests pillow
```

## 🚀 Tính năng

| Tính năng | Mô tả |
|-----------|-------|
| 🤖 Gemini AI | Tự giải audio captcha + visual challenge |
| 👥 Đa tài khoản | Chạy song song nhiều token |
| 🛍️ Shopee | Auto follow/like/comment |
| 🟠 Lazada | Auto follow/like/comment |
| 📋 Lịch sử | Lưu 500 job gần nhất |
| 🔋 Chạy ngầm | Foreground service + Wake Lock |
| 🔄 Auto retry | Watchdog tự reset khi stuck |

## ⚙️ Cách dùng

1. Mở app → splash screen đẹp
2. App tự khởi động Python bot ngầm
3. WebView mở UI tại `localhost:8080`
4. Nhập Bearer token + Account ID
5. Nhấn **Start** → bot tự chạy

## 🏗️ Build từ source

1. Fork repo này
2. Vào **Actions** tab → Enable
3. Push code → GitHub tự build
4. Tải APK từ **Releases**
